package com.melvin.ongandroid.model

data class Testimonio(val id: Int,
                      val name: String,
                      val image: String,
                      val description: String,
)
