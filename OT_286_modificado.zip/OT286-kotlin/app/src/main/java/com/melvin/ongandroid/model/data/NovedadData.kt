package com.melvin.ongandroid.model.data

import com.melvin.ongandroid.model.Novedad

data class NovedadData(

    val success : Boolean,
    val data : List<Novedad>,
    val image : String

)
